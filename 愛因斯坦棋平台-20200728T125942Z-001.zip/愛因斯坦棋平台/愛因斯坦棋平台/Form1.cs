﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 愛因斯坦棋平台
{
    delegate void ChNum(int num);
    public partial class Form1 : Form
    {
        const int port = 10500;
        const int MaxRoom = 50;
        const string Key = "Key";
        const char SpliKey = ' ';



        Socket MySocket;
        Socket[] NodeSocket;

        Room[] room = new Room[MaxRoom];




        int CN = 0;
        public void ChP(int i)
        {
            CN += i;
            ConnectNumber.Text = CN.ToString();
        }


        public Form1()
        {
            InitializeComponent();

            String name = Dns.GetHostName();
            IPAddress[] ip = Dns.GetHostEntry(name).AddressList;
            for (int i = 0; i < ip.Length; i++)
            {
                if (ip[i].AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    MyIP.Text = ip[i].ToString();
                    break;
                }
            }


            MySocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            MySocket.NoDelay = true;

            NodeSocket = new Socket[MaxRoom];

            MySocket.Bind(new IPEndPoint(IPAddress.Any, port));
            MySocket.Listen(10);

            Thread AccUse = new Thread(Connect);
            AccUse.Start();
            RoomInf.RowHeadersWidth += 5;
            for (int i = 0; i < MaxRoom; ++i)
            {
                RoomInf.Rows.Add();
                RoomInf.Rows[i].HeaderCell.Value = Convert.ToString(i);
            }

        }

        void SendMessage(StreamWriter w, string s)
        {
            w.WriteLine(s);
            w.Flush();
        }
        private void Connect()
        {
            Form.CheckForIllegalCrossThreadCalls = false;


            Connect c = new 愛因斯坦棋平台.Connect(MySocket.Accept(), ChP);

            Thread th = new Thread(Connect);
            th.Start();
            try
            {
                if (c.ReadLine().Trim() != Key)
                {
                    c.EXIT();
                    return;
                }
            }
            catch { return; }


            int RoomPos = -1;
            bool IsChreater = false;

            try
            {
                while (true)
                {
                    string line = c.ReadLine().Trim();
                    string[] spli = line.Split(SpliKey);

                    switch (spli[0].Trim().ToLower())
                    {
                        case "exit":
                            c.EXIT();
                            CloseRoom(RoomPos);
                            return;
                        case "addroom":
                            {
                                string RoomName = spli[1].Trim();
                                lock ("RoomLock")
                                {
                                    int NullIndex = -1;
                                    bool SameRoomName = false;
                                    for (int i = 0; i < MaxRoom; ++i)
                                        if (room[i] == null)
                                        {
                                            if (NullIndex == -1) NullIndex = i;
                                        }
                                        else if (room[i].RoomName == RoomName)
                                        {
                                            SameRoomName = true;
                                            break;
                                        }
                                    if (SameRoomName)
                                    {
                                        c.WriteLine("SameRoomNameError");
                                        break;
                                    }
                                    else if (NullIndex == -1)
                                    {
                                        c.WriteLine("IsFullError");
                                        break;
                                    }
                                    else
                                    {
                                        room[RoomPos = NullIndex] = new Room();
                                    }
                                }
                                IsChreater = true;
                                RoomInf.Rows[RoomPos].Cells[0].Value = room[RoomPos].RoomName = RoomName;
                                RoomInf.Rows[RoomPos].Cells[1].Value = c.IP;
                                RoomInf.Rows[RoomPos].Cells[2].Value = spli[2].Trim();
                                room[RoomPos].c[0] = c;

                                c.WriteLine("OK");
                            }
                            break;
                        case "enterroom":
                            {
                                string RoomName = spli[1].Trim();
                                for (int i = 0; i < MaxRoom; ++i)
                                    if (room[i] != null && room[i].RoomName == RoomName)
                                    {
                                        RoomPos = i;
                                        break;
                                    }
                                if (RoomPos == -1) { c.WriteLine("NoThisRoomNameError"); break; }
                                else if (room[RoomPos].IsFull)
                                {
                                    c.WriteLine("ThisRoomFullError"); RoomPos = -1; break;
                                }


                                room[RoomPos].c[1] = c;
                                room[RoomPos].IsFull = true;
                                RoomInf.Rows[RoomPos].Cells[3].Value = c.IP;
                          //      RoomInf.Rows[RoomPos].Cells[4].Value = spli[2].Trim();
                                c.WriteLine("OK");
                                room[RoomPos].c[0].WriteLine("enter");
                            }
                            break;
                        case "talk":
                           room[RoomPos].c[(IsChreater?1:0)].WriteLine(line.Replace("talk ","").Trim());
                           
                            break;
                        default:


                            break;
                    }

                }
            }
            catch
            {
                c.EXIT();
                CloseRoom(RoomPos);
                return;
            }

        }
        void CloseRoom(int i)
        {
            if (i != -1 && room[i] != null)
            {
                room[i].EXIT(); room[i] = null;
                for (int j = 0; j < RoomInf.Rows[i].Cells.Count; ++j) RoomInf.Rows[i].Cells[j].Value = null;
            }
        }
        void EXIT(Socket s)
        {

            try
            {
                s.Shutdown(SocketShutdown.Both);
                s.Disconnect(false);
            }
            catch { }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            try { this.Dispose(); }
            catch { }
            Environment.Exit(Environment.ExitCode);
        }

    }


    class Room
    {
        public string RoomName = "";
        public Board _board = new Board();
        public bool IsFull = false;
        public Connect[] c = new Connect[2];
        public string[] name = new string[2] { "", "" };
        public void EXIT()
        {
            foreach (Connect k in c) if (k != null) k.EXIT();
        }

    }
    class Connect
    {
        public Connect(Socket s, ChNum l)
        {
            Cli = s;
            Cli.NoDelay = true;
            IPPos = (IPEndPoint)Cli.RemoteEndPoint;
            Console.WriteLine("進入:" + IPPos.Address.ToString());
            str = new NetworkStream(Cli);
            rea = new StreamReader(str);
            wri = new StreamWriter(str);
            ll = l;
            l(1);
        }
        ChNum ll;
        public Socket Cli;
        NetworkStream str;
        StreamReader rea;
        StreamWriter wri;
        IPEndPoint IPPos;
        public string IP
        {
            get 
            {
                return IPPos.Address.ToString();
            }
        }
        public string ReadLine()
        {
            string line = rea.ReadLine();
            Console.WriteLine(DateTime.Now.ToShortTimeString() + " :收到:" + IPPos.Address.ToString() + "\t >>" + line + "<<");
            return line;
        }
        public void WriteLine(string s)
        {
            wri.WriteLine(s);
            wri.Flush();
            Console.WriteLine(DateTime.Now.ToShortTimeString() + " :送出:" + IPPos.Address.ToString() + "\t >>" + s + "<<");
        }
        public void EXIT()
        {
            try
            {
                //Cli.Shutdown(SocketShutdown.Both);
                string s = ((IPEndPoint)Cli.RemoteEndPoint).Address.ToString();
                Cli.Dispose();
                str.Dispose();
                rea.Dispose();
                wri.Dispose();
                ll(-1);
                Console.WriteLine("離開:" + s);
            }
            catch
            { }

        }

    }
    class Board
    {
        public byte[] Chess = new byte[12] { 1, 2, 3, 6, 7, 11 ,
                                           25, 24, 23, 20, 19, 15 };
        public byte this[int index]
        {
            set
            {
                Chess[index] = value;
            }
            get
            {
                return Chess[index];
            }
        }
    }


}
