﻿namespace 愛因斯坦棋平台
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.ConnectNumber = new System.Windows.Forms.Label();
            this.RoomInf = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MyIP = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.RoomInf)).BeginInit();
            this.SuspendLayout();
            // 
            // ConnectNumber
            // 
            this.ConnectNumber.AutoSize = true;
            this.ConnectNumber.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.ConnectNumber.Location = new System.Drawing.Point(12, 9);
            this.ConnectNumber.Name = "ConnectNumber";
            this.ConnectNumber.Size = new System.Drawing.Size(20, 21);
            this.ConnectNumber.TabIndex = 0;
            this.ConnectNumber.Text = "0";
            // 
            // RoomInf
            // 
            this.RoomInf.AllowUserToAddRows = false;
            this.RoomInf.AllowUserToDeleteRows = false;
            this.RoomInf.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.RoomInf.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            this.RoomInf.Location = new System.Drawing.Point(12, 33);
            this.RoomInf.Name = "RoomInf";
            this.RoomInf.ReadOnly = true;
            this.RoomInf.RowTemplate.Height = 24;
            this.RoomInf.Size = new System.Drawing.Size(736, 550);
            this.RoomInf.TabIndex = 1;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "房名";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "建房者IP";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "程式名";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "加房者IP";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "程式名";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            // 
            // MyIP
            // 
            this.MyIP.AutoSize = true;
            this.MyIP.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.MyIP.Location = new System.Drawing.Point(563, 9);
            this.MyIP.Name = "MyIP";
            this.MyIP.Size = new System.Drawing.Size(145, 21);
            this.MyIP.TabIndex = 2;
            this.MyIP.Text = "000.000.000.000";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(760, 595);
            this.Controls.Add(this.MyIP);
            this.Controls.Add(this.RoomInf);
            this.Controls.Add(this.ConnectNumber);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            ((System.ComponentModel.ISupportInitialize)(this.RoomInf)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ConnectNumber;
        private System.Windows.Forms.DataGridView RoomInf;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.Label MyIP;

    }
}

